import java.util.ArrayList;
import java.util.List;

public class Cluster {
    public List<TripRecord> points;
    public TripRecord centr;
    public int clus_id;

    public Cluster(int id) {
        this.points = new ArrayList<TripRecord>();
        this.centr = null;
        this.clus_id = id;
    }

    public List<TripRecord> getPoints() {
        return points;
    }

    public TripRecord getcentr() {
        return centr;
    }

    public int getclus_id() {
        return clus_id;
    }

    public void addPoint(TripRecord point) {
        points.add(point);
        point.setCluster(clus_id); // Ask parth about this (my list that i am adding it to)
    }

    public void setCentr(TripRecord centr) {
        this.centr = centr;
    }

    public void setClus_id(int clus_id) {
        this.clus_id = clus_id;
    }

    public void clear() {
        points.clear();
    }

    public GPScoord calculateAverage() {
        double totalX = 0;
        double totalY = 0;
        double numPoints = points.size();
        for (TripRecord p : points) {
            totalX += p.getPickup_location().getLongtitude();
            totalY += p.getPickup_location().getLatitude();
        }
        totalX = totalX / numPoints;
        totalY = totalY / numPoints;

        GPScoord gpScoord = new GPScoord(totalX, totalY);
        return gpScoord;
    }

    public int getSize() {
        return this.points.size();
    }
}
