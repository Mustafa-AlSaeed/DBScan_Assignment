import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DBscan {
    public ArrayList<TripRecord> points;
    private ArrayList<Cluster> clusters;

    public double eps;
    public int minPts;
    public double max_distance;

    public boolean[] visited;

    public DBscan(int minPts, double eps) {
        this.points = new ArrayList<TripRecord>();
        this.clusters = new ArrayList<Cluster>();
        this.eps = eps;
        this.minPts = minPts;
    }

    public void cluster() {
        Iterator<TripRecord> it = points.iterator();
        int n = 0;

        while (it.hasNext()) {
            if (!visited[n]) {
                TripRecord d = (TripRecord) it.next();
                visited[n] = true;
                ArrayList<Integer> neighbors = getNeighbors(d);

                if (neighbors.size() >= minPts) {
                    Cluster c = new Cluster(clusters.size());
                    buildCluster(d, c, neighbors);
                    clusters.add(c);
                }
            }
        }
    }

    private void buildCluster(TripRecord d, Cluster c, ArrayList<Integer> neighbors) {
        c.addPoint(d);
        for (Integer point : neighbors) {
            TripRecord p = points.get(point);
            if (!visited[point]) {
                visited[point] = true;
                ArrayList<Integer> newNeighbors = getNeighbors(p);
                if (newNeighbors.size() >= minPts) {
                    neighbors.addAll(newNeighbors);
                }
            }
            if (p.getclus_id() == -1) {
                c.addPoint(p);
            }
        }
    }

    private ArrayList<Integer> getNeighbors(TripRecord tr) {
        ArrayList<Integer> neighbors = new ArrayList<Integer>();
        int i = 0;
        for (TripRecord point : points) {
            double distance = point.calculateDistance(point.getPickup_location());

            if (distance <= max_distance) {
                neighbors.add(i);
            }
            i++;
        }

        return neighbors;
    }

    public void setPoints(ArrayList<TripRecord> points) {
        this.points = points;
        this.visited = new boolean[points.size()];
    }

    public ArrayList<Cluster> getClusters() {
        return clusters;
    }

}