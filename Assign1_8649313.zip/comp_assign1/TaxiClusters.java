import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

//String pickup_DateTime, GPScoord pickup_location, GPScoord dropoff_location,float trip_Distance
public class TaxiClusters {
    private int minPts;
    private double eps;
    private static ArrayList<TripRecord> startP;

    public TaxiClusters(int minPts, double eps, String filen) throws IOException, FileNotFoundException {
        this.minPts = minPts;
        this.eps = eps;
        startP = new ArrayList<TripRecord>();
        DBscan dbScan = new DBscan(minPts, eps);

        BufferedReader reader = new BufferedReader(new FileReader(filen));
        FileWriter csvWriter = new FileWriter("output.csv");
        String line = "";
        line = reader.readLine();
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            GPScoord pickUp = new GPScoord(Double.parseDouble(data[8]), Double.parseDouble(data[9]));
            GPScoord dropOff = new GPScoord(Double.parseDouble(data[12]), Double.parseDouble(data[13]));
            TripRecord tr = new TripRecord(data[4], pickUp, dropOff, Float.parseFloat(data[7]));
            startP.add(tr);
        }
        reader.close();
        dbScan.setPoints(startP);
        dbScan.cluster();
        ArrayList<Cluster> clusters = dbScan.getClusters();
        for (int i = 0; i < clusters.size(); i++) {
            Cluster temp = clusters.get(i);
            String[] data = { String.valueOf(temp.getclus_id()),
                    String.valueOf(temp.calculateAverage().getLongtitude()),
                    String.valueOf(temp.calculateAverage().getLongtitude()), String.valueOf(temp.getSize()) };
            csvWriter.append(data[0]);
            csvWriter.append(",");
            csvWriter.append(data[1]);
            csvWriter.append(",");
            csvWriter.append(data[2]);
            csvWriter.append(",");
            csvWriter.append(data[3]);
            csvWriter.append("\n");
        }
        csvWriter.flush();
        csvWriter.close();
    }

    public static void main(String[] args) throws IOException, FileNotFoundException {
        TaxiClusters tc = new TaxiClusters(Integer.parseInt(args[1]), Double.parseDouble(args[2]), args[0]);
    }
}
