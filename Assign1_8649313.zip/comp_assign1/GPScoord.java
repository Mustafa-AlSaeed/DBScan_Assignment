public class GPScoord {
    private double longtitude;
    private double latitude;

    public GPScoord(double longtitude, double latitude) {
        this.longtitude = longtitude;
        this.latitude = latitude;
    }

    public Double getLongtitude(){
        return longtitude;
    }

    public Double getLatitude(){
        return latitude;
    }

    public void setLongtitude(Double newerlong){
        this.longtitude = newerlong;
    }

    public void setLatitude(Double newerlat){
        this.latitude = newerlat;
    }

}