import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TripRecord {
    private String pickup_DateTime;
    private GPScoord pickup_location;
    private GPScoord dropoff_location;
    private float trip_Distance;
    private int clus_id;

    public TripRecord(String pickup_DateTime, GPScoord pickup_location, GPScoord dropoff_location,
            float trip_Distance) {
        this.pickup_DateTime = pickup_DateTime;
        this.pickup_location = pickup_location;
        this.dropoff_location = dropoff_location;
        this.trip_Distance = trip_Distance;
    }

    public String getPickup_Datetime() {
        return pickup_DateTime;
    }

    public GPScoord getPickup_location() {
        return pickup_location;
    }

    public GPScoord getDropoff_location() {
        return dropoff_location;
    }

    public float getTrip_Distance() {
        return trip_Distance;
    }

    public int getclus_id() {
        return clus_id;
    }

    public void setPickup_Datetime(String newerPickup_Datetime) {
        this.pickup_DateTime = newerPickup_Datetime;
    }

    public void setPickup_location(GPScoord newerPickup_location) {
        this.pickup_location = newerPickup_location;
    }

    public void setDropoff_location(GPScoord newerDropoff_location) {
        this.dropoff_location = newerDropoff_location;
    }

    public void setTrip_Distance(float newerTrip_Distance) {
        this.trip_Distance = newerTrip_Distance;
    }

    public void setCluster(int clus_id) {
        this.clus_id = clus_id;
    }

    public double calculateDistance(GPScoord val2) {
        double xVal = val2.getLatitude() - this.getPickup_location().getLatitude();
        double yVal = val2.getLongtitude() - this.getPickup_location().getLongtitude();
        double sqxVal = Math.pow(xVal, 2);
        double sqyVal = Math.pow(yVal, 2);

        double finalAns = Math.sqrt(sqxVal + sqyVal);
        return finalAns;
    }
}
